# Mathematics for Data Science
Repository for Stamatics Project 22' - Mathematics for Data Science

### WEEK-1

* Contains three Jupyter notebooks:
  - Notebook 1: Numpy
  - Notebook 2: Data handling of 'Salaries.csv' using pandas
  - Notebook 3: Data handling of 'Ecommerce Purchases' using pandas

### WEEK-2

* Contains two Jupyter notebooks:
  - Notebook 1: Matplotlib
  - Notebook 2: Seaborn

### WEEK-3

* Contains the following Jupyter notebooks and datasets:
  - `01-Linear Regression Project.ipynb`
  - `02-Logistic Regression Project.ipynb`
  - Datasets:
    - `Ecommerce Customers`
    - `advertising.csv`
